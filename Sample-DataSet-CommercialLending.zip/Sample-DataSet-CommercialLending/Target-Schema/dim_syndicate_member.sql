CREATE TABLE IF NOT EXISTS `analytics.dim_syndicate_member` (
  member_id INT64,
  bank_name STRING,
  role STRING,
  bank_rating STRING,
  country STRING
);
